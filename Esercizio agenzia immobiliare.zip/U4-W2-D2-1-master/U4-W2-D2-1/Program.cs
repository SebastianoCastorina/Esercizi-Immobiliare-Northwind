﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace U4_W2_D2_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Agenzia.Start();
        }
    }
}

class Appartamento
{
    public int NumeroVani { get; set; }
    public bool GiardinoTerrazza { get; set; }
    public string TipoAppartamento { get; set; }
    public int Mq { get; set; }
    public string Zona { get; set; }
    public int Costo { get; set; }

    public int CostoMq()
    {
        int costo = 0;
        if(Zona == "Centro")
        {
            costo = Mq * 1200; 
        }
        else if(Zona == "Zona1")
        {
            costo = Mq * 1000;
        }
        else if (Zona == "Zona2")
        {
            costo = Mq * 900;
        }
        else if (Zona == "Zona3")
        {
            costo = Mq * 750;
        }
        else if(Zona == "Periferia"){
            costo = Mq * 600;
        }
        return costo;
    }

    public Appartamento() { }
    public Appartamento(int numeroVani, bool giardinoTerrazza, string tipoAppartamento, int mq, string zona)
    {
        NumeroVani = numeroVani;
        GiardinoTerrazza = giardinoTerrazza;
        TipoAppartamento = tipoAppartamento;
        Mq = mq;
        Zona = zona;
        Costo = CostoMq();
    }
}

class Agenzia
{
    static List<Appartamento> appartamenti = new List<Appartamento>()
    {
        new Appartamento(3,true,"Appartamento",90,"Centro"),
        new Appartamento(8,true,"Villa",300,"Periferia"),
        new Appartamento(2,false,"Appartamento",45,"Zona1"),
        new Appartamento(5,false,"Appartamento",110,"Zona2"),
        new Appartamento(10,true,"Rustico",250,"Zona3"),
        new Appartamento(6,true,"Villa",200,"Centro"),  
        new Appartamento(3,true,"Appartamento",60,"Zona1"),  
        new Appartamento(10,true,"Villa",400,"Centro"),  
        new Appartamento(4,false,"Appartamento",100,"Centro"),  
    };

    static void Lista()
    {
        Console.WriteLine("====== Lista proprieta' disponibili ======");
        foreach(Appartamento app in appartamenti)
        {
            Console.WriteLine($"Numero di vani: {app.NumeroVani} - Giadino/Terrazza: {app.GiardinoTerrazza} - Tipo di appartamento: {app.TipoAppartamento} - MQ: {app.Mq} - Zona: {app.Zona} - Prezzo: €{app.Costo:N}");      
        }
    }

    static void NuovaProprieta()
    {
        Console.Write("Insersci il numero di vani: ");
        int numVani = Int32.Parse(Console.ReadLine());
        Console.Write("Inserisci se ha giardino/terrazza (true/false): ");
        bool giardTerr = bool.Parse(Console.ReadLine());
        Console.Write("Inserisci il tipo di appartamento (Appartamento/Villa/Rustico): ");
        string tipoApp = Console.ReadLine();
        Console.Write("Inserisci i Mq: ");
        int appMq = Int32.Parse(Console.ReadLine());
        Console.Write("Inserisci la zona (Centro/Zona1/Zona2/Zona3/Periferia): ");
        string appZona = Console.ReadLine();

        appartamenti.Add(new Appartamento(numVani, giardTerr, tipoApp, appMq, appZona));
        Console.WriteLine("====== Lista delle proprieta' aggiornata ======");
        Lista();
    }

    static void CercaProprieta()
    {
        List<Appartamento> appartamentiFiltrati = new List<Appartamento>();
        Console.Write("Inserisci il tuo budget: ");
        int budget = Int32.Parse(Console.ReadLine());
        Console.Write("Inserisci i Mq: ");
        int mq = Int32.Parse(Console.ReadLine());
        Console.Write("Inserisci la zona (Centro/Zona1/Zona2/Zona3/Periferia): ");
        string zona = Console.ReadLine();
        foreach(Appartamento app in appartamenti)
        {
            if(app.Mq == mq && app.Zona == zona)
            {
                if(budget >= app.Costo) 
                {
                    appartamentiFiltrati.Add(app);
                }
            }
        }
        if(appartamentiFiltrati.Count > 0)
        {
            Console.WriteLine("====== Lista delle proprieta' filtrata ======");
            foreach(Appartamento appFiltrato in appartamentiFiltrati)
            {
                Console.WriteLine($"Numero di vani: {appFiltrato.NumeroVani} - Giadino/Terrazza: {appFiltrato.GiardinoTerrazza} - Tipo di appartamento: {appFiltrato.TipoAppartamento} - MQ: {appFiltrato.Mq} - Zona: {appFiltrato.Zona} - Prezzo: €{appFiltrato.Costo:N}");
            }
        }
        else
        {
            Console.WriteLine("Non ci sono proprieta' con le caratteristiche cercate");
        }
    }

    public static void Start()
    {
        Console.WriteLine("$$$$$ Agenzia di Mario Rossi $$$$$");
        Console.WriteLine("1. Mosta la lista delle proprieta'");
        Console.WriteLine("2. Aggiungi una nuova proprieta'");
        Console.WriteLine("3. Cerca una proprieta'");
        Console.WriteLine("0. Esci");
        string scelta = Console.ReadLine();
        Console.WriteLine();
        if(scelta == "1")
        {
            Lista();
            Console.WriteLine();
            Start();
        }
        else if(scelta == "2")
        {
            NuovaProprieta();
            Console.WriteLine();
            Start();
        }
        else if(scelta == "3")
        {
            CercaProprieta();
            Console.WriteLine();
            Start();
        }
        else if(scelta == "0")
        {
            Console.WriteLine("Arrivedrci");
            Thread.Sleep(1000);
            Environment.Exit(0);
        }
        else
        {
            Console.WriteLine("Scelta non valida. Riprovare.");
            Console.WriteLine();
            Start();
        }
        Console.ReadLine();
    }
}
